from google.cloud import bigquery
import pandas
import json
import pyarrow

def Make_Query_JSON(request):
   
    sd = '2020-03-14'
    ed = '2020-03-14'
    para = "*"
    request_json = request.get_json()

    if(len(request_json)==2):
      sd = request_json['sd']
      ed = request_json['ed']
    elif(len(request_json)==3):
        sd = request_json['sd']
        ed = request_json['ed']
        para = ','.join(request_json['fields'])

    project = 'tgs-internal-saige-dev-001'
    dataset_id = 'di_interns_capstone'
    table_id = 'Covid-19_stats'
    client = bigquery.Client(project=project)

    sql = """
        SELECT {}
        FROM `tgs-internal-saige-dev-001.di_interns_capstone.Covid-19_stats` 
        WHERE Date_YMD BETWEEN DATE('{}') AND DATE('{}')
        ORDER BY Date_YMD,States
    """.format(para,sd,ed)

    job = client.query(sql).to_dataframe()
    res = job.to_json(orient='records',date_format='iso')
    res  = json.loads(res)
    try:
        for item in res:
            item["Date_YMD"] = item["Date_YMD"].split("T")[0]
    except:
        st = "Exception for KeyError"
        
    result = json.dumps(res)
    return result
