import requests
import json

def getToken(request):
    request_json = request.get_json()
    Url = request_json['url']
    metadataServerTokenURL = 'http://metadata/computeMetadata/v1/instance/service-accounts/default/identity?audience='
    headers = {'Metadata-Flavor': 'Google'}
    r = requests.post(metadataServerTokenURL + Url,headers = headers)   
    token = r.text 
    dic = [{"token":str(token)}]
    tt = json.dumps(dic)
    return tt