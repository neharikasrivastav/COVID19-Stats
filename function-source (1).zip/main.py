import requests
import pandas as pd
from datetime import date, timedelta
from google.cloud import storage
from itertools import chain
import csv
from google.cloud import bigquery

def fetch_csv(url):
    CSV_URL = url
    with requests.Session() as s:
        download = s.get(CSV_URL)
        decoded_content = download.content.decode('utf-8')
        cr = csv.reader(decoded_content.splitlines(), delimiter=',')
        my_list = list(cr)
        df = pd.DataFrame(my_list[1:], columns = my_list[0])
        return df

def create_folder(request):
    folder_name =''.join( str(date.today() - timedelta(days = 1)).split('-'))
    storage_client = storage.Client()
    bucket = storage_client.bucket("di_interns_capstone")
    filename= f"Covid-19_stats/{folder_name}/"
    bucket.blob(filename).upload_from_string('')
    return folder_name

def format_date(x):
    st = x.split('/')[::-1]
    if len(st[-1])!=2:
        st[-1] = '0'+st[-1]
    if len(st[-2])!=2:
        st[-2] = '0'+st[-2]
    return '-'.join(st)

def Remodel_dataframe(event,context):

    # Creating Folder to Store fetched csv

    folder = str(create_folder('Create'))
    
    # Initialization

    fields=['Date_YMD','States','Confirmed','Recovered',
             'Deceased','ICMR-RTPCR','Vaccine-Doses-administered']

    states_name = ['Andaman and Nicobar Islands', 'Andhra Pradesh', 'Arunachal Pradesh', 
        'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 'Dadra and Nagar Haveli and Daman and Diu',
        'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 
        'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 
        'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Puducherry',
        'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 
        'Uttar Pradesh', 'Uttarakhand', 'West Bengal','Miscellaneous','Total_India']
    
    # Modifying the state_wise_daily.csv

    df = pd.read_csv('https://api.covid19india.org/csv/latest/state_wise_daily.csv')
    df['DN'] +=df['DD']
    df.drop(["DD"], axis = 1, inplace = True)
    
    # Making Empty Dataframe with Fields/Columns

    make_df = pd.DataFrame(columns = fields)
    
    # Loading Date_YMD Data's till Yesterday
    
    yesterday = str(date.today() - timedelta(days = 1))
    mydates = pd.date_range('2020-03-14', yesterday).to_list()
    gen_date = [[str(x).split()[0]]*len(states_name) for x in mydates]
    make_df['Date_YMD'] = list(chain.from_iterable(gen_date))

    # Loading States Data's
    
    states = [states_name]*(len(make_df['Date_YMD'])//len(states_name))
    make_df['States'] = list(chain.from_iterable(states))

    # Loading Confirmed, Recovered, Deceased Data's
    
    val1 = []
    val2 = []
    val3 = []
    for i in range(0,len(df['Date_YMD']),3):
        if df.iloc[i,1] in list(make_df['Date_YMD']):
            for j in range(4,len(df.columns)):
                val1.append(df.iloc[i,j])
                val2.append(df.iloc[i+1,j])
                val3.append(df.iloc[i+2,j])
            val1.append(df.iloc[i,3])
            val2.append(df.iloc[i+1,3])
            val3.append(df.iloc[i+2,3])
        else:
            for j in range(4,len(df.columns)):
                val1.append(0)
                val2.append(0)
                val3.append(0)
            val1.append(0)
            val2.append(0)
            val3.append(0)
    no_zero = len(make_df['Date_YMD']) - len(val1)
    zero = [0]*no_zero
    val1+=zero
    val2+=zero
    val3+=zero

    make_df['Confirmed'] = val1
    make_df['Recovered'] = val2
    make_df['Deceased'] = val3
    
    # Loading Vaccine-Doses Data's
    
    val2.clear()
 
    vd = pd.read_csv('https://api.covid19india.org/csv/latest/vaccine_doses_statewise.csv')
    vd_columns = list(map(format_date,list(vd.columns)[1:]))
    ymd = list(make_df['Date_YMD'])
    
    for i in range(0,len(make_df['Date_YMD']),len(states_name)):
        if ymd[i] in vd_columns:
            for j in range(0,len(vd['State'])):
                val2.append(vd.iloc[j,vd_columns.index(ymd[i])+1])
           
        else:
            for j in range(0,len(vd['State'])):
                val2.append(0)
    no_zero = len(make_df['Date_YMD']) - len(val2)
    zero = [0]*no_zero
    val2+=zero
    make_df['Vaccine-Doses-administered'] = val2

    # Loding ICMR_RTPCR Data's
    
    rtpcr = fetch_csv('https://api.covid19india.org/csv/latest/statewise_tested_numbers_data.csv')
   
    rtpcr_columns = list(map(format_date,list(rtpcr['Updated On'])))
    s = list(make_df['States'])
    d = list(make_df['Date_YMD'])
    ymd= list(zip(d,s))
    upo = rtpcr_columns
    st = list(rtpcr['State'])
    ymd_rtpcr = list(zip(upo,st))
       
    for i in range(0,len(ymd)):
        if ymd[i] in ymd_rtpcr:
            make_df.iloc[i,5] = rtpcr.iloc[ymd_rtpcr.index(ymd[i]),5]
        
        else:
            make_df.iloc[i,5] = 0
            
    for i in range(0,len(ymd)):
        if(make_df.iloc[i,5]==""):
            make_df.iloc[i,5] = 0
        else:
            make_df.iloc[i,5] = int(make_df.iloc[i,5])

    another_states_name = [f"{x}-Total" for x in states_name]
    another_fields = fields
            
    temp_make_df = pd.DataFrame(columns = another_fields)
    temp_make_df['States'] = another_states_name
    temp_make_df['Date_YMD'] = [yesterday]*38
    temp_make_df['Confirmed'] = [0]*38
    temp_make_df['Recovered'] = [0]*38
    temp_make_df['Deceased'] = [0]*38
    temp_make_df['ICMR-RTPCR'] = [0]*38
    temp_make_df['Vaccine-Doses-administered'] = [0]*38
    
    for i in range(0,len(ymd),38):
        make_df.iloc[i+37,5] = sum([int(x) for x in list(make_df.iloc[i:i+36,5])])
        temp_make_df.iloc[0:38,2] += [int(x) for x in list(make_df.iloc[i:i+38,2])]
        temp_make_df.iloc[0:38,3] += [int(x) for x in list(make_df.iloc[i:i+38,3])]
        temp_make_df.iloc[0:38,4] += [int(x) for x in list(make_df.iloc[i:i+38,4])]
    temp_make_df.iloc[0:38,5] += [int(x) for x in list(make_df.iloc[len(make_df)-38:len(make_df),5])]
    temp_make_df.iloc[0:38,6] += [int(x) for x in list(make_df.iloc[len(make_df)-38:len(make_df),6])]
    
    make_df = make_df.append(temp_make_df,ignore_index = True)
    
    storage_client = storage.Client()
    bucket = storage_client.bucket("di_interns_capstone")

    filename= "Covid-19_stats/Master_Datasets.csv"
    filename1= f"Covid-19_stats/{folder}/state_wise_daily.csv"
    filename2= f"Covid-19_stats/{folder}/statewise_tested_numbers_data.csv"
    filename3= f"Covid-19_stats/{folder}/vaccine_doses_statewise.csv"

    bucket.blob(filename).upload_from_string(data=make_df.to_csv(index=False),content_type='text/csv')
    bucket.blob(filename1).upload_from_string(data=df.to_csv(index=False),content_type='text/csv')
    bucket.blob(filename2).upload_from_string(data=rtpcr.to_csv(index=False),content_type='text/csv')
    bucket.blob(filename3).upload_from_string(data=vd.to_csv(index=False),content_type='text/csv')

    print(f"Created Folder: {folder}\nCreated Files: 3\nCreated Master_Datasets.csv")

    ##Loading the data to table

    client = bigquery.Client()
    table_id = "tgs-internal-saige-dev-001.di_interns_capstone.Covid-19_stats"
    job_config = bigquery.LoadJobConfig(
    schema = [
        bigquery.SchemaField("Date_YMD", "DATE", mode="NULLABLE"),
        bigquery.SchemaField("States", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("Confirmed", "INTEGER", mode="NULLABLE"),
        bigquery.SchemaField("Recovered", "INTEGER", mode="NULLABLE"),
        bigquery.SchemaField("Deceased", "INTEGER", mode="NULLABLE"),
        bigquery.SchemaField("ICMR_RTPCR", "FLOAT", mode="NULLABLE"),
        bigquery.SchemaField("Vaccine_Doses_administered", "INTEGER", mode="NULLABLE"),
        
    ],
    write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,
    skip_leading_rows=1,
    source_format=bigquery.SourceFormat.CSV,
    )
    uri = "gs://di_interns_capstone/Covid-19_stats/Master_Datasets.csv"

    load_job = client.load_table_from_uri(
        uri, table_id, job_config=job_config
    )  

    load_job.result() 

    destination_table = client.get_table(table_id)
    up_date = str(date.today() - timedelta(days = 1))

    print("Created table {}\nLoaded {} rows\nUpdated Table rows till Date: {}".format(table_id,destination_table.num_rows,up_date))
    
    #return "Created table {}\nLoaded {} rows\nUpdated Table rows till Date: {}".format(table_id,destination_table.num_rows,up_date)

    # return f"Created Folder: {folder}\nCreated Files: 3\nCreated Master_Datasets.csv"